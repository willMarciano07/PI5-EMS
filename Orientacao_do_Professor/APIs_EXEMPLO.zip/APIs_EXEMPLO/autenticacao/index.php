<?php 
$host = 'http://www.thyagoquintas.com.br:3306';
$db   = 'db_xx';
$user = 'user_xx';
$pass = 'senha';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);


      // Ajuste para receber usuÃ¡rio e senha via GET (para simplificaÃ§Ã£o)
      $usuario = isset($_GET['usuario']) ? $_GET['usuario'] : '';
      $senha = isset($_GET['senha']) ? $_GET['senha'] : '';

      // Query para buscar usuÃ¡rio especÃ­fico
      $sql = "SELECT USUARIO_ID as usuarioId, USUARIO_NOME as usuarioNome, USUARIO_EMAIL as usuarioEmail, USUARIO_SENHA as usuarioSenha,USUARIO_CPF as usuarioCpf FROM USUARIO WHERE USUARIO_EMAIL = :usuario AND USUARIO_SENHA = :senha";
      $stmt = $pdo->prepare($sql);
      $stmt->execute(['usuario' => $usuario, 'senha' => $senha]);

      $usuarios = $stmt->fetchAll();

      header('Content-Type: application/json');
      echo json_encode($usuarios);

  } catch (\PDOException $e) {
      echo "Erro de conexÃ£o: " . $e->getMessage();
      exit;
  }
  ?>
