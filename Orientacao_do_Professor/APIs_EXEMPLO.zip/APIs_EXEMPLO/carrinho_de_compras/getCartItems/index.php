<?php 
$host = 'http://www.thyagoquintas.com.br:3306';
$db   = 'db_xx';
$user = 'user_xx';
$pass = 'senha';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['userId'])) {
        $userId = $_GET['userId'];
        // Incluindo um JOIN adicional com a tabela PRODUTO_IMAGEM para acessar IMAGEM_URL
        $stmt = $pdo->prepare("SELECT 
    CI.PRODUTO_ID, 
    CI.ITEM_QTD AS QUANTIDADE_DISPONIVEL, 
    P.PRODUTO_NOME, 
    P.PRODUTO_PRECO, 
    PI.IMAGEM_URL
FROM 
    CARRINHO_ITEM CI
JOIN 
    PRODUTO P ON CI.PRODUTO_ID = P.PRODUTO_ID
JOIN 
    PRODUTO_IMAGEM PI ON P.PRODUTO_ID = PI.PRODUTO_ID
JOIN 
    (SELECT 
         PRODUTO_ID, 
         MIN(IMAGEM_ORDEM) AS MIN_IMAGEM_ORDEM
     FROM 
         PRODUTO_IMAGEM
     GROUP BY 
         PRODUTO_ID) AS PI2 ON PI.PRODUTO_ID = PI2.PRODUTO_ID AND PI.IMAGEM_ORDEM = PI2.MIN_IMAGEM_ORDEM
WHERE 
    CI.USUARIO_ID = ?
GROUP BY 
    CI.PRODUTO_ID, CI.ITEM_QTD, P.PRODUTO_NOME, P.PRODUTO_PRECO, PI.IMAGEM_URL

");
        $stmt->execute([$userId]);
        $items = $stmt->fetchAll();
        echo json_encode($items);
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userId = $_POST['userId'];
    $productId = $_POST['productId'];
    $quantity = $_POST['quantity'];
    $stmt = $pdo->prepare("INSERT INTO CARRINHO_ITEM (USUARIO_ID, PRODUTO_ID, ITEM_QTD) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE ITEM_QTD = quantity + VALUES(quantity)");
    $stmt->execute([$userId, $productId, $quantity]);
} elseif ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    parse_str(file_get_contents("php://input"), $_DELETE);
    $userId = $_DELETE['userId'];
    $productId = $_DELETE['produtoId'];
    $stmt = $pdo->prepare("DELETE FROM CARRINHO_ITEM WHERE USUARIO_ID = ? AND PRODUTO_ID = ?");
    echo $userId;
    echo "-";
    echo $productId;
    $stmt->execute([$userId, $productId]);
