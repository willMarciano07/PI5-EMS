<?php
    $host = 'http://www.thyagoquintas.com.br:3306'; 
    $db   = 'db_xx';
    $user = 'user_xx';
    $pass = 'senha';
    $charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

$userId = $_POST['userId'];
$produtoId = $_POST['produtoId'];
$quantidade = $_POST['quantidade'];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    // Verificar se existe no carrinho
    $checkSql = "SELECT * FROM CARRINHO_ITEM WHERE USUARIO_ID = ? AND PRODUTO_ID = ?";
    $stmt = $pdo->prepare($checkSql);
    $stmt->execute([$userId, $produtoId]);
    $item = $stmt->fetch();

    if ($item) {
        // Atualiza quantidade se jÃ¡ existir
        $updateSql = "UPDATE CARRINHO_ITEM SET ITEM_QTD = ITEM_QTD + ? WHERE USUARIO_ID = ? AND PRODUTO_ID = ?";
        $stmt = $pdo->prepare($updateSql);
        $stmt->execute([$quantidade, $userId, $produtoId]);
    } else {
        // Adiciona novo item no carrinho caso ainda nao exista
        $insertSql = "INSERT INTO CARRINHO_ITEM (USUARIO_ID, PRODUTO_ID, ITEM_QTD) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($insertSql);
        $stmt->execute([$userId, $produtoId, $quantidade]);
    }

    echo "Item adicionado/atualizado no carrinho.";
} catch (PDOException $e) {
    echo "Erro de conexÃ£o: " . $e->getMessage();
}
?>