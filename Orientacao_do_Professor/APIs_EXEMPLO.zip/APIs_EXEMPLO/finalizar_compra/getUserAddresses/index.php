<?php
header("Content-Type: application/json");

function conectarAoBancoDeDados() {
    $host = 'http://www.thyagoquintas.com.br:3306'; 
    $db   = 'db_xx';
    $user = 'user_xx';
    $pass = 'senha';
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    try {
        return new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        error_log("Erro ao conectar ao banco de dados: " . $e->getMessage());
        return null; 
    }
}

function getAddresses($pdo, $userId) {
    $sql = "SELECT * FROM ENDERECO WHERE USUARIO_ID = ? AND ENDERECO_APAGADO = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$userId,0]);
    return $stmt->fetchAll();
}

try {
    $pdo = conectarAoBancoDeDados();
    $userId = isset($_GET['userId']) ? intval($_GET['userId']) : null;
    error_log("Received UserID: " . $userId);

    if ($pdo === null) {
        throw new Exception("Falha na conexão com o banco de dados.");
    }

    if ($userId === null) {
        throw new Exception("UserID não fornecido.");
    }

    $addresses = getAddresses($pdo, $userId);
    error_log("Addresses: " . json_encode($addresses));
    echo json_encode($addresses);
} catch (Exception $e) {
    echo json_encode(['status' => 'erro', 'code' => 400, 'message' => $e->getMessage()]);
}
?>
