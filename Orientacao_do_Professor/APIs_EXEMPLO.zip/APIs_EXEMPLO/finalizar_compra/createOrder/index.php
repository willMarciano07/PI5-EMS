<?php
header("Content-Type: application/json");

function conectarAoBancoDeDados() {
    $host = 'http://www.thyagoquintas.com.br:3306'; 
    $db   = 'db_xx';
    $user = 'user_xx';
    $pass = 'senha';
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    try {
        return new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        error_log("Erro ao conectar ao banco de dados: " . $e->getMessage());
        return null; 
    }
}

function processarPedido($pdo) {
    if ($pdo === null) {
        throw new Exception("Falha na conexão com o banco de dados.");
    }

    $dadosEntrada = file_get_contents("php://input");
    $dadosPost = json_decode($dadosEntrada, true);
    $usuarioId = $dadosPost['userId'];
    $produtos = $dadosPost['products'];
    $endereco = $dadosPost['addressId'];
    $total = 0;

    $pedidoId = inserirPedido($pdo, $usuarioId, $total, $endereco);
    manipularProdutos($pdo, $produtos, $pedidoId, $usuarioId);
    
    return $pedidoId; 
}

function inserirPedido($pdo, $usuarioId, $total, $endereco) {
    $sqlPedido = "INSERT INTO PEDIDO (USUARIO_ID, STATUS_ID, PEDIDO_DATA, ENDERECO_ID) VALUES (?, ?, ?, ?)";
    $stmtPedido = $pdo->prepare($sqlPedido);
    $dataPedidoFormatada = date('Y-m-d');
    $stmtPedido->execute([$usuarioId, 1, $dataPedidoFormatada, $endereco]);
    return $pdo->lastInsertId();
}

function manipularProdutos($pdo, $produtos, $pedidoId, $usuarioId) {
    foreach ($produtos as $produto) {
        $produtoId = $produto['PRODUTO_ID'];
        $quantidade = $produto['QUANTIDADE_DISPONIVEL'];
        $preco = $produto['PRODUTO_PRECO'];
        if (verificarEstoque($pdo, $produtoId, $quantidade)) {
            inserirItemPedido($pdo, $produtoId, $pedidoId, $quantidade, $preco);
            atualizarEstoque($pdo, $produtoId, $quantidade, $usuarioId);
        } else {
            throw new Exception("Quantidade insuficiente no estoque para o produto ID: $produtoId");
        }
    }
}

function verificarEstoque($pdo, $produtoId, $quantidade) {
    $sqlVerificar = "SELECT PRODUTO_QTD FROM PRODUTO_ESTOQUE WHERE PRODUTO_ID = ?";
    $stmtVerificar = $pdo->prepare($sqlVerificar);
    $stmtVerificar->execute([$produtoId]);
    $linha = $stmtVerificar->fetch();
    return $linha && $linha['PRODUTO_QTD'] >= $quantidade;
}

function inserirItemPedido($pdo, $produtoId, $pedidoId, $quantidade, $preco) {
    $sqlItem = "INSERT INTO PEDIDO_ITEM (PRODUTO_ID, PEDIDO_ID, ITEM_QTD, ITEM_PRECO) VALUES (?, ?, ?, ?)";
    $stmtItem = $pdo->prepare($sqlItem);
    $stmtItem->execute([$produtoId, $pedidoId, $quantidade, $preco]);

}

function atualizarEstoque($pdo, $produtoId, $quantidade, $usuarioId) {
    $sqlEstoque = "UPDATE PRODUTO_ESTOQUE SET PRODUTO_QTD = PRODUTO_QTD - ? WHERE PRODUTO_ID = ?";
    $stmtEstoque = $pdo->prepare($sqlEstoque);
    $stmtEstoque->execute([$quantidade, $produtoId]);

    limparCarrinho($pdo, $produtoId, $usuarioId);
}

function limparCarrinho($pdo, $produtoId, $usuarioId) {
    $sqlLimparCarrinho = "UPDATE CARRINHO_ITEM SET ITEM_QTD = 0 WHERE PRODUTO_ID = ? AND USUARIO_ID = ?";
    $stmtLimparCarrinho = $pdo->prepare($sqlLimparCarrinho);
    $stmtLimparCarrinho->execute([$produtoId, $usuarioId]);
}

try {
    $pdo = conectarAoBancoDeDados();
    $resposta = processarPedido($pdo);
    echo json_encode(['status' => 'sucesso', 'code' => 200, 'message' => 'Pedido ' . $resposta . ' criado com sucesso']);
} catch (Exception $e) {
        echo json_encode(['status' => 'erro', 'code' => 400, 'message' => $e->getMessage()]);
}
?>