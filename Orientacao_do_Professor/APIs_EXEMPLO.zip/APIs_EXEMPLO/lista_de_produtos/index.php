<?php 
    $host = 'http://www.thyagoquintas.com.br:3306'; 
    $db   = 'db_xx';
    $user = 'user_xx';
    $pass = 'senha';
    $charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    //$sql = "SELECT * FROM PRODUTO";
    
    //$sql = "SELECT p.*, pi.IMAGEM_URL FROM PRODUTO p LEFT JOIN PRODUTO_IMAGEM pi ON p.PRODUTO_ID = pi.PRODUTO_ID";

  $sql = "SELECT p.*, pi.IMAGEM_URL, e.PRODUTO_QTD AS QUANTIDADE_DISPONIVEL
  FROM PRODUTO p
  LEFT JOIN PRODUTO_IMAGEM pi ON p.PRODUTO_ID = pi.PRODUTO_ID
  LEFT JOIN PRODUTO_ESTOQUE e ON p.PRODUTO_ID = e.PRODUTO_ID";
  
    $stmt = $pdo->query($sql);
  
    $produtos = $stmt->fetchAll();

    header('Content-Type: application/json');
    echo json_encode($produtos);

} catch (\PDOException $e) {
    echo "Erro de conexão: " . $e->getMessage();
    exit;
}
?>